package quickcheck.utils

import quickcheck.HeapProperties

trait CorrectProperties extends HeapProperties :
  // The content of this file has been removed from the handout.
  // It is used by the grading infrastructure to provide better feedback.
end CorrectProperties
